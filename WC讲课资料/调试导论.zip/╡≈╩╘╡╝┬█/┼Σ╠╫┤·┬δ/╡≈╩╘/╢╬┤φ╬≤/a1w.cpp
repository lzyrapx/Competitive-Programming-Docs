#include <cstdio>
#include <cstdlib>

int a[10005];

int main(void)
{
    printf("%d\n",a[10000]);
    
    return 0;
}
