#include <cstdio>
#include <cstdlib>

int main(void)
{
    int n;

    scanf("%d",&n);
    printf("%d\n",1<<n);

    // if(n == 5) puts("lalala");

    return 0;
}
